package com.review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmyDuniaApplicationTests {

	@Test
	void contextLoads() {
	}

}
