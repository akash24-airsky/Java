package com.vinod;

import org.springframework.stereotype.Component;

@Component
public class DemoService {

	public void m1() {
		System.out.println("Hello DON!");
	}
}
