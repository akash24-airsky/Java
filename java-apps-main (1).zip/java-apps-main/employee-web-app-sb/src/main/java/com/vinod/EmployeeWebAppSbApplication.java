package com.vinod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeWebAppSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeWebAppSbApplication.class, args);
	}

}
