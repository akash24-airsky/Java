package com.vinod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeWebAppSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
